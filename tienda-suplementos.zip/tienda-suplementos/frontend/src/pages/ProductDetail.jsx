import ProductDetail from '../components/ProductDetail';

export default function ProductDetailPage() {
	return <ProductDetail />;
}

