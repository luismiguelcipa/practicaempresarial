import { Link } from 'react-router-dom';
import './Header.css';

const Header = () => {
  return (
    <header className="header">
      <div className="header-container">
        {/* Logo */}
        <Link to="/" className="logo">
          SportSupps
        </Link>

        {/* Navigation Links */}
        <nav className="nav-menu">
          <Link to="/" className="nav-link">
            Inicio
          </Link>
          <Link to="/products" className="nav-link">
            Productos
          </Link>
          <Link to="/cart" className="nav-link">
            Ofertas
          </Link>
          <Link to="/login" className="nav-link">
            Contacto
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;